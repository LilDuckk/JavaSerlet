package nguyenngocviet.beans;

public class NguyenNgocViet_2110900054_Product {

		private String maSP;
		private String tenSP;
		private int soLuong;
		private float donGia;
		private String anh;
		
		public NguyenNgocViet_2110900054_Product() {
			
		}

		public NguyenNgocViet_2110900054_Product(String maSP, String tenSP, int soLuong, float donGia, String anh) {
			super();
			this.maSP = maSP;
			this.tenSP = tenSP;
			this.soLuong = soLuong;
			this.donGia = donGia;
			this.anh = anh;
		}

		public String getMaSP() {
			return maSP;
		}

		public void setMaSP(String maSP) {
			this.maSP = maSP;
		}

		public String getTenSP() {
			return tenSP;
		}

		public void setTenSP(String tenSP) {
			this.tenSP = tenSP;
		}

		public int getSoLuong() {
			return soLuong;
		}

		public void setSoLuong(int soLuong) {
			this.soLuong = soLuong;
		}

		public float getDonGia() {
			return donGia;
		}

		public void setDonGia(float donGia) {
			this.donGia = donGia;
		}

		public String getAnh() {
			return anh;
		}

		public void setAnh(String anh) {
			this.anh = anh;
		}		
	}

		
		

